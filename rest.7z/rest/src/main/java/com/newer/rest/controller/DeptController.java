package com.newer.rest.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.newer.rest.mapper.DeptMapper;
import com.newer.rest.pojo.Dept;



/**
 * 
 * RESTful 控制器
 * 
 * @author Administrator
 *
 */
@RestController
@RequestMapping("/api/dept")
//@ResponseBody  响应体的数据而不是视图名  
//@Controller
public class DeptController {
	
	// 控制器中需要数据访问操作
	
//	@Resource
	
	
	// 自动注入（让容器创建该资源并自动传递进来，赋值，不为null）
	
	@Autowired
	DeptMapper deptMapper;
	
	// GET /dept
	@GetMapping
	public List<Dept>list() {
		return deptMapper.finAll();
		
	}
	
	@GetMapping("/{id}")
	public Dept load(@PathVariable int id) {
		return deptMapper.load(id);
	}
	
	
	
	@GetMapping("/get/{deptName}")
	public int get(@PathVariable String deptName) {
		return deptMapper.foundDept(deptName);
	}
	// POST /dept
	
	//版本一：表单提交
//	@PostMapping
//	public Dept create(Dept dept) {
//		deptMapper.save(dept);
//		return dept;
//	}
	
	// 版本二： AJAX JS异步提交 JSON格式数据    @RequestBody 
	@PostMapping
	public Dept create(@RequestBody Dept dept) {
		deptMapper.save(dept);
		return dept;
	}
//	
	
	
	// DELETE /dept/3
	@DeleteMapping("/{id}")
	public void remove(@PathVariable int id) {
		deptMapper.remove(id);
	}
	
	// put/dept/3
	// @RequestBody   通过 js 异步的数据提交
	@PutMapping("/{id}")
	public void update(
			@PathVariable int id,
			@RequestBody Dept dept) {
		
		dept.setId(id);
		deptMapper.update(dept);
	}

}
