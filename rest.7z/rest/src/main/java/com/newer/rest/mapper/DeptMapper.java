package com.newer.rest.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.newer.rest.pojo.Dept;
import com.newer.rest.pojo.Staff;

/**
 * 
 * MyBatis 提供一种 SQL 映射技术 ：基于反射和注解以及动态代理（）实现了，数据访问操作   
 *  
 * @author Administrator
 *
 */

@Mapper
public interface DeptMapper {
	
	// 实体持久化后获得数据库生成的标号
	@Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
	@Insert("insert into dept(title,loc) values(#{title},#{city})")
	void save(Dept dept);
	
	// loc --> city 尚未完成
	@Select("select * from dept where id=#{id}")
	@Results(
			id= "deptMap",
			value= {
			@Result(column="loc",property="city"),
			@Result(column = "id",property = "id"),
			@Result(column = "title",property = "title"),
			@Result(
					property = "staffList",
					column = "id",
					javaType = List.class,
					many =@Many(select ="findStaffByDeptId")
					)
	})
	Dept load(int id);
	
	@Select("select id,name,job,sale from staff where dept_id=#{id}")
	List<Staff> findStaffByDeptId(int id);
	
	@Select("select * from dept")
	@ResultMap("deptMap")
//	@Results(
//			id= "deptMap",
//			value= {
//			@Result(column="loc",property="city"),
//			@Result(column = "id",property = "id"),
//			@Result(column = "title",property = "title")
//	})
	List<Dept> finAll();
	
	
	@Update("update dept set title=#{title},loc=#{city} where id=#{id}")
	void update(Dept dept);
	
	
	@Delete("delete from dept where id=#{id}")
	void remove(int id);
	
	//
	
	@Select("select id from dept where title=#{deptName}")
	int foundDept(String deptName);
	

}
