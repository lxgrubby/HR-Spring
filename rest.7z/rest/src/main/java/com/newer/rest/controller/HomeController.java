package com.newer.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {
	
	@GetMapping("/")
	public String home() {
		return "index.html";
	}
	
	@GetMapping("/dept")
	public String dept() {
		return "dept.html";
	}
	
	@GetMapping("/staff")
	public String staff() {
		return "staff.html";
	}
	
	
//	@Autowired
//	DeptMapper mapper;
//	
//	
//	//表单提交 （同步操作）
//	@PostMapping("/api/dept")
//	public String dept(Dept dept) {
//		//save 
//		mapper.save(dept);	
//		
//		
//		//请求转发
////		return "/";
//		
//		// 相应重定向
//		return "redirect:/";
//	}
	

}
