package com.newer.rest.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.newer.rest.pojo.Dept;
import com.newer.rest.pojo.Staff;

@Mapper
public interface StaffMapper {
	
	
	/**
	 * 
	 * 创建
	 * 
	 * @param staff
	 */
	@Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
	@Insert("insert into staff(name,job,sale,dept_id,mgr) values(#{name},#{job},#{sale},#{dept.id},#{boss.id})")
//	@ResultMap("staffMap")
	//
//	@Results(
//			value = {
//					@Result(
//							column = "dept_id",
//							property = "dept.id",
//							javaType = Dept.class,
//							one =@One(select="com.newer.rest.mapper.DeptMapper.foundDept")
//							),
//					@Result(
//							column = "mgr",
//							property = "boss.id",
//							javaType = Staff.class,
//							one =@One(select="com.newer.rest.mapper.StaffMapper.fundboss")
//							)
//			}
//			)
//	@Results(
//			value= {
//					@Result(
//							column = "dept_id",
//							property = "id",
//							javaType = Dept.class,
//							one =@One(select ="com.newer.rest.mapper.DeptMapper.load")),
//			}
//			)
	void save(Staff staff);
	
	
	/**
	 *  加载一个员工对象
	 * @param id
	 * @return
	 */
	@Select("select * from staff where id=#{id}")
	// 对象的属性 --》表的列
	// 命名的映射（可复用）
	@Results(id="staffMap",
			value= {
					@Result(column = "id",property = "id"),
					@Result(
							column = "dept_id",
							property = "dept",
							javaType = Dept.class,
							one =@One(select ="com.newer.rest.mapper.DeptMapper.load")),
					@Result(
							column ="mgr",
							property = "boss",
							javaType = Staff.class,
							one =@One(select ="com.newer.rest.mapper.StaffMapper.loadMgr")
							),
					@Result(
							column = "id",
							property = "underling",
							javaType = List.class,
							many = @Many(select = "findUnderLing")
							)
					
			})
	Staff load(int id);
	/**
	 * 检索特定员工的下属
	 * @param id
	 * @return
	 */
	@Select("select id,name,job,sale from staff where mgr=#{id}")
	List<Staff> findUnderLing(int id);
	
	
	@Select("select id,name from staff where id=#{id}")
	Staff loadMgr(int id);
	
	
	@Select("select id from staff where name=#{boss}")
	int fundBoss(String boss);
	
	/**
	 * 加载所有
	 * 
	 * @return
	 */
	// 复用已命名的映射
	@Select("select * from staff")
	@ResultMap("staffMap")
	List<Staff> findAll();
	
	
	
	@Update("update staff set name=#{name},job=#{job},sale=#{sale} where id=#{id}")
	void update(Staff staff);
	
	
	@Delete("delete from staff where id=#{id}")
	void remove(int id);

}
