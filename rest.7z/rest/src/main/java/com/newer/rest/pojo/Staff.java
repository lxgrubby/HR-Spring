package com.newer.rest.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Staff {
	 
	int id;
	
	String name;
	
	String job;
	
	BigDecimal sale;
	
	//dept_id
	Dept dept;
	
	Staff boss;
	
	/**
	 * 下属
	 */
	List<Staff> underling =new ArrayList<>();
	
	public List<Staff> getUnderling() {
		return underling;
	}
	
	public void setUnderling(List<Staff> underling) {
		this.underling = underling;
	}
	
	public void setBoss(Staff boss) {
		this.boss = boss;
	}
	public Staff getBoss() {
		return boss;
	}
	
	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	
	public Staff() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public BigDecimal getSale() {
		return sale;
	}

	public void setSale(BigDecimal sale) {
		this.sale = sale;
	}

	@Override
	public String toString() {
		return "Staff [id=" + id + ", name=" + name + ", job=" + job + ", sale=" + sale + ", dept=" + dept + "]";
	}
	
	
	


}
