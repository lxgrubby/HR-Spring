package com.newer.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.newer.rest.mapper.StaffMapper;
import com.newer.rest.pojo.Staff;


@RestController
@RequestMapping("/api/staff")
public class StaffController {
	
	@Autowired
	StaffMapper staffMapper;
	
	// GET /api/staff
	@GetMapping
	public List<Staff>list() {
		return staffMapper.findAll();
		
	}
	
	// GET /api/staff/{id}
	@GetMapping("/{id}")
	public Staff load(@PathVariable int id) {
		return staffMapper.load(id);
	}
	
	// POST /staff
	
	//版本一：表单提交
//	@PostMapping
//	public Staff create(Staff staff) {
//		staffMapper.save(staff);
//		return staff;
//	}
	
	// 版本二： AJAX JS异步提交 JSON格式数据    @RequestBody 
	@PostMapping
	public Staff create(@RequestBody Staff staff) {
		staffMapper.save(staff);
		return staff;
	}
	
	
	
	// DELETE /staff/3
	@DeleteMapping("/{id}")
	public void remove(@PathVariable int id) {
		staffMapper.remove(id);
	}
	
	// put/staff/3
	// @RequestBody   通过 js 异步的数据提交
	@PutMapping("/{id}")
	public void update(
			@PathVariable int id,
			@RequestBody Staff staff) {
		
		staff.setId(id);
		staffMapper.update(staff);
	}

}
